package tv.own.owntv.core.companion

import android.content.Context
import androidx.annotation.StringRes
import org.json.JSONObject
import tv.own.owntv.core.R
import tv.own.owntv.core.model.SourceAnalysisAiState
import tv.own.owntv.core.model.SourceMessageConfidence
import tv.own.owntv.core.model.SourceType

/**
 * Localized HTML renderer for the companion web UI. Markup, CSS and protocol identifiers remain
 * here; every sentence or label visible to the remote browser is resolved from Android resources first.
 */
internal object CompanionHtml {

    /** Day intervals the companion page offers; any 1–99 figure can still be set on the TV itself. */
    private val COMPANION_DAY_PRESETS = listOf(1, 2, 7, 14, 30)

    private const val CSS = """
      :root{
        color-scheme: dark;
        --bg:#040E0B; --panel:#12191700; --card:#1B211F; --card-2:#252B29;
        --line:#3F4945; --text:#DEE4E1; --muted:#BFC9C4;
        --accent:#8CEE2B; --accent-ink:#123A06; --danger:#FFB4AB;
      }
      @font-face{
        font-family:'Lora'; font-style:normal; font-weight:400 700;
        src:url('/lora.ttf') format('truetype'); font-display:swap;
      }
      *{box-sizing:border-box}
      body{
        margin:0; color:var(--text);
        font-family:system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;
        background:
          radial-gradient(1200px 520px at 12% -12%, rgba(140,238,43,0.10) 0%, transparent 60%),
          radial-gradient(900px 460px at 100% 0%, rgba(140,238,43,0.06) 0%, transparent 62%),
          var(--bg);
        min-height:100vh;
      }
      h1,h2,.brand{font-family:'Lora',Georgia,'Noto Sans',system-ui,sans-serif; font-weight:700; letter-spacing:.2px}
      main{max-width:760px; margin:0 auto; padding:28px 20px 56px}
      .brandrow{display:flex; align-items:center; gap:12px; margin-bottom:22px}
      .dot{width:34px; height:34px; border-radius:10px; background:#52DBC8;
        display:grid; place-items:center; color:#003730}
      .dot svg{width:18px; height:18px}
      .brand{font-size:20px; color:var(--text)}
      .card{background:var(--card); border:1px solid var(--line); border-radius:20px;
        padding:26px 22px; box-shadow:0 24px 60px rgba(0,0,0,.45)}
      h1{margin:0 0 8px; font-size:24px}
      h2{margin:0 0 8px; font-size:20px}
      p{line-height:1.55; color:var(--muted); margin:0 0 16px}
      form{display:grid; gap:14px}
      label{display:grid; gap:6px; font-size:14px; color:var(--text)}
      input,select,textarea{border:1px solid var(--line); border-radius:12px; padding:13px 14px;
        background:#0C1311; color:var(--text); font-size:16px; width:100%; font-family:inherit}
      textarea{resize:vertical; min-height:110px; line-height:1.45}
      input:focus,select:focus,textarea:focus{outline:none; border-color:var(--accent);
        box-shadow:0 0 0 3px rgba(140,238,43,.20)}
      .grid{display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px}
      .checks{display:grid; gap:10px; grid-template-columns:repeat(2,minmax(0,1fr)); margin-top:2px}
      .check{display:flex; align-items:center; gap:9px; color:var(--muted)}
      .check input{width:18px; height:18px}
      .tabs{display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:10px; margin-bottom:18px}
      /* Four tabs (Xtream / M3U / Stalker / From message): as many fit, two per row on a phone. */
      .tabs.wrap{grid-template-columns:repeat(auto-fit,minmax(110px,1fr))}
      .tab{border:1px solid var(--line); border-radius:12px; padding:12px 10px; background:var(--card-2);
        color:var(--muted); font-weight:600; font-size:15px; cursor:pointer; font-family:inherit}
      .tab.active{border-color:var(--accent); background:#1E2E0C; color:#EAFFD0}
      .panel{display:none}
      .panel.active{display:grid; gap:14px}
      button.go{border:0; border-radius:12px; padding:15px 16px; background:var(--accent);
        color:var(--accent-ink); font-weight:700; font-size:16px; cursor:pointer; margin-top:4px}
      .pin{font-family:'Lora',Georgia,'Noto Sans',system-ui,sans-serif; font-size:34px; letter-spacing:12px; text-align:center;
        padding:16px; caret-color:var(--accent)}
      .err{color:var(--danger); font-size:14px; margin:0 0 12px}
      .hint{font-size:13px; color:var(--muted); margin-top:6px}
      a{color:var(--accent)}
      /* Pick list (SELECT_ITEMS): three levels in one document, one sticky save bar. */
      [hidden]{display:none!important}
      .picker{display:grid; gap:16px; padding-bottom:104px}
      .lv{display:grid; gap:12px}
      .appbar{position:sticky; top:0; z-index:3; display:flex; align-items:center; gap:8px; padding:10px 0;
        background:linear-gradient(180deg,rgba(4,14,11,.97) 0%,rgba(4,14,11,.88) 70%,rgba(4,14,11,0) 100%)}
      .apptitle{font-size:20px; margin:0 2px}
      .back{border:1px solid var(--line); background:var(--card-2); color:var(--text); font:inherit;
        font-size:14px; font-weight:600; border-radius:10px; padding:9px 12px; cursor:pointer}
      .desc{color:var(--muted); margin:0}
      .rows{display:grid; gap:8px}
      .row{display:flex; align-items:center; gap:10px; color:var(--text); text-decoration:none;
        background:var(--card); border:1px solid var(--line); border-radius:14px; padding:12px 14px}
      .row .grow{flex:1; min-width:0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap}
      .row .chev{color:var(--muted); font-size:20px; line-height:1}
      [dir=rtl] .chev{transform:scaleX(-1)}
      .count{background:var(--card-2); border:1px solid var(--line); color:var(--muted);
        border-radius:999px; padding:2px 9px; font-size:12px; font-weight:600}
      .lv .check{font-size:16px; padding:10px 2px; gap:12px; border-bottom:1px solid rgba(63,73,69,.5)}
      .lv .check:last-child{border-bottom:0}
      .acc{border:1px solid var(--line); border-radius:14px; background:var(--card); padding:0 14px}
      .acc>summary{cursor:pointer; padding:13px 0; font-weight:700; list-style:none}
      .acc>summary::-webkit-details-marker{display:none}
      .acc[open]>summary{border-bottom:1px solid var(--line)}
      .acc .rows{padding:12px 0}
      .quick{display:flex; gap:8px; margin:0 0 2px}
      .mini{border:1px solid var(--line); background:var(--card-2); color:var(--muted); font:inherit;
        font-size:13px; border-radius:10px; padding:8px 12px; cursor:pointer}
      .tabs.fit{grid-template-columns:repeat(auto-fit,minmax(110px,1fr)); margin-bottom:0}
      /* The addresses found in a message: one per row, long URLs break instead of overflowing. */
      .picks{display:grid; gap:8px; margin:10px 0}
      .picks .url{word-break:break-all}
      .savebar{position:fixed; left:0; right:0; bottom:0; z-index:4; display:flex; align-items:center; gap:10px;
        padding:12px 20px calc(12px + env(safe-area-inset-bottom));
        background:linear-gradient(0deg,rgba(4,14,11,.98) 0%,rgba(4,14,11,.92) 70%,rgba(4,14,11,0) 100%)}
      .savebar .go{flex:1; margin:0}
      .savebar.dirty .go{box-shadow:0 0 0 3px rgba(140,238,43,.25)}
      @media (max-width:640px){.grid,.checks,.tabs{grid-template-columns:1fr}
        .tabs.wrap{grid-template-columns:repeat(2,minmax(0,1fr))}}
    """

    private const val LOGO_SVG =
        """<svg viewBox="0 0 24 24" fill="none"><path d="M8 5v14l11-7z" fill="currentColor"/></svg>"""

    private class Copy(private val context: Context) {
        private fun s(@StringRes id: Int): String = context.getString(id)

        val app = s(R.string.app_name)
        val pinTitle = s(R.string.companion_pin_page_title)
        val pinHeading = s(R.string.companion_pin_heading)
        val pinDescription = s(R.string.companion_pin_description)
        val pinPlaceholder = s(R.string.companion_pin_placeholder)
        val pinAria = s(R.string.companion_pin_aria)
        val continueLabel = s(R.string.companion_continue)
        val pinMismatch = s(R.string.companion_pin_mismatch)

        val tmdbTitle = s(R.string.companion_tmdb_page_title)
        val tmdbHeading = s(R.string.companion_tmdb_heading)
        val tmdbDescription = s(R.string.companion_tmdb_description)
        val tmdbGetKey = s(R.string.companion_tmdb_get_key)
        val tmdbKeyLabel = s(R.string.settings_tmdb_api_key)
        val tmdbInvalid = s(R.string.companion_tmdb_invalid)
        val tmdbSentBody = s(R.string.companion_tmdb_sent_body)
        val tmdbSentLink = s(R.string.companion_tmdb_sent_link)

        val aiKeyTitle = s(R.string.companion_ai_key_page_title)
        val aiKeyHeading = s(R.string.companion_ai_key_heading)
        val aiKeyDescription = s(R.string.companion_ai_key_description)
        val aiKeyGetKey = s(R.string.companion_ai_key_get_key)
        val aiKeyLabel = s(R.string.companion_ai_key_label)
        val aiKeyInvalid = s(R.string.companion_ai_key_invalid)
        val aiKeySentBody = s(R.string.companion_ai_key_sent_body)
        val aiKeySentLink = s(R.string.companion_ai_key_sent_link)

        val addTitle = s(R.string.companion_add_page_title)
        val addHeading = s(R.string.companion_add_heading)
        val addDescription = s(R.string.companion_add_description)
        val xtream = s(R.string.setup_xtream)
        val m3u = s(R.string.setup_m3u)
        val stalker = s(R.string.setup_stalker_mac)
        val name = s(R.string.setup_source_name_optional)
        val defaultIptv = s(R.string.setup_default_iptv)
        val defaultPlaylist = s(R.string.setup_name_default_playlist)
        val defaultPortal = s(R.string.setup_default_portal)
        val serverUrl = s(R.string.setup_server_url)
        val serverExample = s(R.string.setup_server_example)
        val playlistUrl = s(R.string.setup_playlist_url_local_file)
        val playlistExample = s(R.string.setup_playlist_example)
        val playlistFile = s(R.string.companion_playlist_file)
        val playlistUrlOrFile = s(R.string.companion_playlist_url_or_file)
        val portalUrl = s(R.string.setup_portal_url)
        val portalExample = s(R.string.setup_portal_example)
        val mac = s(R.string.setup_mac_address)
        val username = s(R.string.setup_username)
        val password = s(R.string.setup_password)
        val userAgent = s(R.string.setup_user_agent_optional)
        val optional = s(R.string.settings_metadata_optional)
        val epgUrl = s(R.string.settings_epg_sources_url)
        val epgExample = s(R.string.settings_epg_sources_url_hint)
        val syncXtreamHint = s(R.string.companion_sync_xtream_hint)
        val syncStalkerHint = s(R.string.companion_sync_stalker_hint)
        val live = s(R.string.setup_live_tv)
        val movies = s(R.string.setup_movies)
        val series = s(R.string.setup_series)
        val now = s(R.string.setup_now)
        val later = s(R.string.setup_later)
        val off = s(R.string.setup_off)
        val autoRefresh = s(R.string.setup_auto_refresh)
        val refreshStartup = s(R.string.settings_sources_refresh_startup)
        val refresh6 = s(R.string.settings_sources_refresh_6h)
        val refresh12 = s(R.string.settings_sources_refresh_12h)
        // The TV form lets the user name any number of days; a web <select> cannot, so it offers the
        // common ones and the exact figure can still be changed on the TV afterwards.
        val refreshDays = COMPANION_DAY_PRESETS.associateWith {
            context.resources.getQuantityString(R.plurals.settings_sources_refresh_days, it, it)
        }
        val defaultPlaylistLabel = s(R.string.companion_default_playlist)
        val sendToTv = s(R.string.companion_send_to_tv)

        val importTab = s(R.string.companion_import_tab)
        val importHeading = s(R.string.companion_import_heading)
        val importDescription = s(R.string.companion_import_description)
        val importMessageLabel = s(R.string.companion_import_message_label)
        val importConsent = s(R.string.companion_import_consent)
        val importConsentMissing = s(R.string.companion_import_consent_missing)
        val importAnalyze = s(R.string.companion_import_analyze)
        val importAnalyzing = s(R.string.companion_import_analyzing)
        val importConfirmTitle = s(R.string.companion_import_confirm_title)
        val importConfirmHeading = s(R.string.companion_import_confirm_heading)
        val importConfirmDescription = s(R.string.companion_import_confirm_description)
        val importTypeLabel = s(R.string.companion_import_type_label)
        val importChooseUrl = s(R.string.companion_import_choose_url)
        val importShowUrl = s(R.string.companion_import_show_url)
        val importReadByAi = s(R.string.companion_import_read_by_ai)
        val importReadByRules = s(R.string.companion_import_read_by_rules)
        val importAiNoKey = s(R.string.companion_import_ai_no_key)
        val importAiInvalidKey = s(R.string.companion_import_ai_invalid_key)
        val importAiNoCredit = s(R.string.companion_import_ai_no_credit)
        val importAiFailed = s(R.string.companion_import_ai_failed)
        val importAiDisabled = s(R.string.companion_import_ai_disabled)
        val importGuessed = s(R.string.companion_import_guessed)
        val importNothingFound = s(R.string.companion_import_nothing_found)
        val importMissingFields = s(R.string.companion_import_missing_fields)

        val savedTitle = s(R.string.companion_saved_page_title)
        val savedHeading = s(R.string.companion_saved_heading)
        val savedSendAnother = s(R.string.companion_saved_send_another)
        val savedBackupBody = s(R.string.companion_saved_backup_body)
        val savedBackupLink = s(R.string.companion_saved_backup_link)
        val savedImageBody = s(R.string.companion_saved_image_body)
        val savedImageLink = s(R.string.companion_saved_image_link)

        val backupTitle = s(R.string.companion_backup_page_title)
        val backupHeading = s(R.string.companion_backup_heading)
        val backupDescription = s(R.string.companion_backup_description)
        val backupFile = s(R.string.companion_backup_file)
        val chooseBackup = s(R.string.companion_choose_backup)
        val sending = s(R.string.companion_sending)
        val couldNotReach = s(R.string.companion_could_not_reach)
        val couldNotRead = s(R.string.companion_could_not_read)
        // Full sentence template; the browser substitutes only the numeric HTTP status after the
        // Android resource has supplied the localized sentence and punctuation.
        val uploadFailed = s(R.string.companion_upload_failed).replace("%1\$d", "__STATUS__")

        val imageTitle = s(R.string.companion_image_page_title)
        val imageHeading = s(R.string.companion_image_heading)
        val imageDescription = s(R.string.companion_image_description)
        val imageFile = s(R.string.companion_image_file)
        val chooseImage = s(R.string.companion_choose_image)
        val imageTooLarge = s(R.string.companion_image_too_large)

        val downloadTitle = s(R.string.companion_download_page_title)
        val downloadHeading = s(R.string.companion_download_heading)
        val downloadDescription = s(R.string.companion_download_description)
        val downloadBackup = s(R.string.companion_download_backup)

        val selectDescription = s(R.string.companion_select_description)
        val selectSearch = s(R.string.companion_select_search)
        val selectSave = s(R.string.companion_select_save)
        val selectBack = s(R.string.companion_select_back)
        val selectManageAll = s(R.string.companion_select_manage_all)
        val selectAll = s(R.string.companion_select_all)
        val selectNone = s(R.string.companion_select_none)
        val selectEmpty = s(R.string.companion_select_empty)
        val selectSentHeading = s(R.string.companion_select_sent_heading)
        val selectSentBody = s(R.string.companion_select_sent_body)
        val selectSentLink = s(R.string.companion_select_sent_link)
    }

    private fun page(context: Context, title: String, inner: String): String {
        val c = Copy(context)
        // AppLocale.wrap() resolves the effective device locale when the stored tag is empty.
        // Advertise that effective locale to browser screen readers and choose the matching writing
        // direction; never use the persisted empty tag itself as the HTML language.
        val locale = context.resources.configuration.locales[0]
            ?: java.util.Locale.getDefault()
        val lang = locale.toLanguageTag().ifBlank { "en" }
        val dir = if (context.resources.configuration.layoutDirection == android.view.View.LAYOUT_DIRECTION_RTL) "rtl" else "ltr"
        return """
            <!doctype html><html lang="${lang.h()}" dir="$dir"><head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>${title.h()}</title><style>$CSS</style>
            </head><body><main>
              <div class="brandrow"><span class="dot">$LOGO_SVG</span><span class="brand">${c.app.h()}</span></div>
              $inner
            </main></body></html>
        """.trimIndent()
    }

    fun pinPage(context: Context, error: String?): String {
        val c = Copy(context)
        return page(context, c.pinTitle, """
            <div class="card">
              <h1>${c.pinHeading.h()}</h1>
              <p>${c.pinDescription.h()}</p>
              ${if (error != null) "<p class=\"err\">${error.h()}</p>" else ""}
              <form method="post" action="/">
                <input class="pin" name="pin" inputmode="numeric" pattern="[0-9]*" maxlength="6"
                       autofocus placeholder="${c.pinPlaceholder.h()}" aria-label="${c.pinAria.h()}" required>
                <button class="go" type="submit">${c.continueLabel.h()}</button>
              </form>
            </div>
        """.trimIndent())
    }

    /**
     * The add-source page: the three source forms plus — when the host app can read messages — the
     * "From message" panel.
     */
    fun formPage(
        context: Context,
        pin: String,
        messagePanel: CompanionMessagePanel = CompanionMessagePanel(),
    ): String {
        val c = Copy(context)
        // The message panel is the one the page opens on when the user has just been sent back to
        // it (a missing consent) — otherwise the Xtream form leads, as before.
        val messageActive = messagePanel.available && messagePanel.active
        val xtreamPanel = if (messageActive) "panel" else "panel active"
        return page(context, c.addTitle, """
            <div class="card">
              <h1>${c.addHeading.h()}</h1>
              <p>${c.addDescription.h()}</p>
              <div class="tabs wrap">
                <button type="button" class="tab${if (messageActive) "" else " active"}" data-k="xtream">${c.xtream.h()}</button>
                <button type="button" class="tab" data-k="m3u">${c.m3u.h()}</button>
                <button type="button" class="tab" data-k="stalker">${c.stalker.h()}</button>
                ${if (messagePanel.available) "<button type=\"button\" class=\"tab${if (messageActive) " active" else ""}\" data-k=\"message\">${c.importTab.h()}</button>" else ""}
              </div>

              <form class="$xtreamPanel" data-k="xtream" method="post" action="/xtream?pin=$pin">
                <input type="hidden" name="type" value="xtream">
                <div class="grid">
                  <label>${c.name.h()} <input name="name" placeholder="${c.defaultIptv.h()}"></label>
                  ${autoRefreshSelect(c)}
                </div>
                <label>${c.serverUrl.h()} <input name="server" placeholder="${c.serverExample.h()}" required></label>
                <div class="grid">
                  <label>${c.username.h()} <input name="user" autocomplete="username" required></label>
                  <label>${c.password.h()} <input name="pass" type="password" autocomplete="current-password" required></label>
                </div>
                <label>${c.userAgent.h()} <input name="userAgent" placeholder="${c.optional.h()}"></label>
                <label>${c.epgUrl.h()} <input name="epgUrl" placeholder="${c.optional.h()}"></label>
                <p class="hint">${c.syncXtreamHint.h()}</p>
                <div class="grid">
                  ${scopeSelect(c, "syncLive", c.live)}
                  ${scopeSelect(c, "syncMovies", c.movies)}
                  ${scopeSelect(c, "syncSeries", c.series)}
                </div>
                <input type="hidden" name="isDefault" value="false">
                <label class="check"><input type="checkbox" name="isDefault" value="true"> ${c.defaultPlaylistLabel.h()}</label>
                <button class="go" type="submit">${c.sendToTv.h()}</button>
              </form>

              <form class="panel" id="m3uForm" data-k="m3u" method="post" action="/m3u?pin=$pin">
                <input type="hidden" name="type" value="m3u">
                <div class="grid">
                  <label>${c.name.h()} <input name="name" placeholder="${c.defaultPlaylist.h()}"></label>
                  ${autoRefreshSelect(c)}
                </div>
                <label>${c.playlistUrl.h()} <input id="m3uUrl" name="server" placeholder="${c.playlistExample.h()}"></label>
                <label>${c.playlistFile.h()} <input id="m3uFile" type="file" accept=".m3u,.m3u8,audio/x-mpegurl,application/vnd.apple.mpegurl,text/plain"></label>
                <label>${c.userAgent.h()} <input name="userAgent" placeholder="${c.optional.h()}"></label>
                <label>${c.epgUrl.h()} <input name="epgUrl" placeholder="${c.optional.h()}"></label>
                <input type="hidden" name="isDefault" value="false">
                <label class="check"><input type="checkbox" name="isDefault" value="true"> ${c.defaultPlaylistLabel.h()}</label>
                <button class="go" id="m3uSend" type="submit">${c.sendToTv.h()}</button>
                <p id="m3uStatus" class="hint"></p>
              </form>

              <form class="panel" data-k="stalker" method="post" action="/stalker?pin=$pin">
                <input type="hidden" name="type" value="stalker">
                <div class="grid">
                  <label>${c.name.h()} <input name="name" placeholder="${c.defaultPortal.h()}"></label>
                  ${autoRefreshSelect(c)}
                </div>
                <label>${c.portalUrl.h()} <input name="portalUrl" placeholder="${c.portalExample.h()}" required></label>
                <label>${context.getString(R.string.setup_mac_address).h()} <input name="mac" placeholder="${context.getString(R.string.setup_mac_example).h()}" required></label>
                <h3>${context.getString(R.string.setup_stalker_advanced_identity).h()}</h3>
                <div class="grid">
                  <label>${context.getString(R.string.setup_stalker_serial_number_optional).h()} <input name="serialNumber"></label>
                  <label>${context.getString(R.string.setup_stalker_device_id_optional).h()} <input name="deviceId"></label>
                  <label>${context.getString(R.string.setup_stalker_device_id2_optional).h()} <input name="deviceId2"></label>
                  <label>${context.getString(R.string.setup_stalker_signature_optional).h()} <input name="signature"></label>
                </div>
                <label>${c.userAgent.h()} <input name="userAgent" placeholder="${c.optional.h()}"></label>
                <p class="hint">${c.syncStalkerHint.h()}</p>
                <div class="grid">
                  ${scopeSelect(c, "syncLive", c.live, "now")}
                  ${scopeSelect(c, "syncMovies", c.movies, "later")}
                  ${scopeSelect(c, "syncSeries", c.series, "later")}
                </div>
                <input type="hidden" name="isDefault" value="false">
                <label class="check"><input type="checkbox" name="isDefault" value="true"> ${c.defaultPlaylistLabel.h()}</label>
                <button class="go" type="submit">${c.sendToTv.h()}</button>
              </form>
${if (messagePanel.available) messagePanelHtml(c.importLabels(), pin, messagePanel.message, messagePanel.error, messagePanel.active) else ""}
            </div>
            <script>
              var tabs=document.querySelectorAll('.tab'), panels=document.querySelectorAll('.panel');
              tabs.forEach(function(t){t.addEventListener('click',function(){
                var k=t.getAttribute('data-k');
                tabs.forEach(function(x){x.classList.toggle('active',x===t)});
                panels.forEach(function(p){p.classList.toggle('active',p.getAttribute('data-k')===k)});
              });});
              // M3U panel only. With no file chosen this stays a plain form post, exactly as before.
              // With a file chosen the browser reads it as text and posts it as JSON, because a file
              // input cannot travel in a normal urlencoded body and the TV has no multipart parser.
              var mf=document.getElementById('m3uFile'), mu=document.getElementById('m3uUrl'),
                  mb=document.getElementById('m3uSend'), ms=document.getElementById('m3uStatus');
              document.getElementById('m3uForm').addEventListener('submit',function(ev){
                var file=mf.files&&mf.files[0];
                if(!file){
                  if(!(mu.value||'').trim()){ms.textContent=${c.playlistUrlOrFile.js()};ev.preventDefault();return false;}
                  return true; // URL only — let the browser submit the form the old way.
                }
                ev.preventDefault();
                mb.disabled=true; ms.textContent=${c.sending.js()};
                var body={};
                new FormData(document.getElementById('m3uForm')).forEach(function(v,k){body[k]=v;});
                var r=new FileReader();
                r.onload=function(){
                  body.playlistFile=r.result; body.playlistFileName=file.name;
                  fetch('/m3u?pin=$pin',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
                    .then(function(res){
                      if(res.ok){document.open();res.text().then(function(t){document.write(t);document.close();});}
                      else{mb.disabled=false;ms.textContent=${c.uploadFailed.js()}.replace('__STATUS__',String(res.status));}
                    })
                    .catch(function(){mb.disabled=false;ms.textContent=${c.couldNotReach.js()};});
                };
                r.onerror=function(){mb.disabled=false;ms.textContent=${c.couldNotRead.js()};};
                r.readAsText(file);
                return false;
              });
              // Message panel: the button waits for a message and for the consent, and the status
              // line says what the TV is doing while the analysis runs.
              var msgForm=document.getElementById('messageForm'), msgText=document.getElementById('srcMessage'),
                  msgConsent=document.getElementById('srcConsent'), msgSend=document.getElementById('srcAnalyze'),
                  msgStatus=document.getElementById('srcStatus');
              if(msgForm){
                var msgReady=function(){
                  msgSend.disabled=!((msgText.value||'').trim().length && msgConsent.checked);
                };
                msgText.addEventListener('input',msgReady);
                msgConsent.addEventListener('change',msgReady);
                msgReady();
                msgForm.addEventListener('submit',function(){
                  msgSend.disabled=true; msgStatus.textContent=${c.importAnalyzing.js()};
                });
              }
            </script>
        """.trimIndent())
    }

    /**
     * Every label the two message pages show.
     *
     * The renderers take them instead of a [Context], so the pages — the paste panel and the
     * confirmation — stay unit-testable on the JVM, the same split [CompanionSelectHtml] uses.
     */
    data class ImportLabels(
        val heading: String,
        val description: String,
        val messageLabel: String,
        val consent: String,
        val analyze: String,
        val analyzing: String,
        val confirmHeading: String,
        val confirmDescription: String,
        val typeLabel: String,
        val xtream: String,
        val m3u: String,
        val stalker: String,
        val name: String,
        val namePlaceholder: String,
        val serverUrl: String,
        val portalUrl: String,
        val username: String,
        val password: String,
        val mac: String,
        val sendToTv: String,
        val chooseUrl: String,
        val showUrl: String,
        val readByAi: String,
        val readByRules: String,
        val aiNoKey: String,
        val aiInvalidKey: String,
        val aiNoCredit: String,
        val aiFailed: String,
        val aiDisabled: String,
        val guessed: String,
        val nothingFound: String,
        val missingFields: String,
    )

    /** The labels of the message pages, taken from the resources of the current locale. */
    private fun Copy.importLabels(): ImportLabels = ImportLabels(
        heading = importHeading,
        description = importDescription,
        messageLabel = importMessageLabel,
        consent = importConsent,
        analyze = importAnalyze,
        analyzing = importAnalyzing,
        confirmHeading = importConfirmHeading,
        confirmDescription = importConfirmDescription,
        typeLabel = importTypeLabel,
        xtream = xtream,
        m3u = m3u,
        stalker = stalker,
        name = name,
        namePlaceholder = defaultIptv,
        serverUrl = serverUrl,
        portalUrl = portalUrl,
        username = username,
        password = password,
        mac = mac,
        sendToTv = sendToTv,
        chooseUrl = importChooseUrl,
        showUrl = importShowUrl,
        readByAi = importReadByAi,
        readByRules = importReadByRules,
        aiNoKey = importAiNoKey,
        aiInvalidKey = importAiInvalidKey,
        aiNoCredit = importAiNoCredit,
        aiFailed = importAiFailed,
        aiDisabled = importAiDisabled,
        guessed = importGuessed,
        nothingFound = importNothingFound,
        missingFields = importMissingFields,
    )

    /**
     * The "From message" panel: a text field for the pasted provider message, the consent that
     * lets the message be read by the AI, and the button that starts the analysis.
     *
     * The consent is a checkbox, so an unticked box is simply not part of the POST — the server
     * then sends the message nowhere and hands the page back with the error.
     */
    internal fun messagePanelHtml(
        labels: ImportLabels,
        pin: String,
        message: String,
        error: String?,
        active: Boolean,
    ): String = """
              <form class="panel${if (active) " active" else ""}" id="messageForm" data-k="message" method="post" action="/source/analyze?pin=$pin">
                <h2>${labels.heading.h()}</h2>
                <p>${labels.description.h()}</p>
                <label>${labels.messageLabel.h()} <textarea id="srcMessage" name="message" rows="7">${message.h()}</textarea></label>
                <label class="check"><input type="checkbox" id="srcConsent" name="consent" value="1"><span>${labels.consent.h()}</span></label>
                ${if (error != null) "<p class=\"err\">${error.h()}</p>" else ""}
                <button class="go" id="srcAnalyze" type="submit">${labels.analyze.h()}</button>
                <p id="srcStatus" class="hint"></p>
              </form>
    """.trimIndent()

    /**
     * The confirm page: the values read from the message, pre-filled and editable, plus the choice
     * of address when the message held more than one.
     */
    fun sourceConfirmPage(
        context: Context,
        pin: String,
        analysis: CompanionSourceAnalysis,
        message: String,
    ): String {
        val c = Copy(context)
        return page(context, c.importConfirmTitle, sourceConfirmBody(c.importLabels(), pin, analysis, message))
    }

    /**
     * The body of the confirm page: the type, the values, the choice of address and the button.
     *
     * The type can be changed, and the form follows it: the endpoint, the name of the URL field and
     * the fields that belong to the type. The TV still receives the ordinary payload — the page
     * only fills the form, the import is started there.
     */
    internal fun sourceConfirmBody(
        labels: ImportLabels,
        pin: String,
        analysis: CompanionSourceAnalysis,
        message: String,
    ): String {
        val type = when (analysis.type) {
            SourceType.M3U -> "m3u"
            SourceType.STALKER -> "stalker"
            else -> "xtream"
        }
        val hints = buildList {
            if (!analysis.hasContent) {
                add(labels.nothingFound)
            } else {
                if (analysis.confidence == SourceMessageConfidence.GUESS) add(labels.guessed)
                add(
                    when {
                        // The values on show are the AI's.
                        analysis.fromAi -> labels.readByAi
                        // The AI read the message, but these values are the local ones.
                        analysis.aiState == SourceAnalysisAiState.USED -> labels.readByRules
                        else -> aiHint(labels, analysis.aiState)
                    },
                )
            }
        }
        return """
            <div class="card">
              <h1>${labels.confirmHeading.h()}</h1>
              <p>${labels.confirmDescription.h()}</p>
              ${hints.joinToString("") { "<p class=\"hint\">${it.h()}</p>" }}
${urlChoiceHtml(labels, analysis, message, pin)}
              <form id="srcForm" method="post" action="/$type?pin=$pin">
                <label>${labels.typeLabel.h()}
                  <select name="type" id="srcType">
                    <option value="xtream"${if (type == "xtream") " selected" else ""}>${labels.xtream.h()}</option>
                    <option value="m3u"${if (type == "m3u") " selected" else ""}>${labels.m3u.h()}</option>
                    <option value="stalker"${if (type == "stalker") " selected" else ""}>${labels.stalker.h()}</option>
                  </select>
                </label>
                <label>${labels.name.h()} <input name="name" placeholder="${labels.namePlaceholder.h()}"></label>
                <label><span id="srcUrlLabel">${labels.serverUrl.h()}</span> <input id="srcUrl" name="server" value="${analysis.server.h()}"></label>
                <div class="grid" id="srcXtreamFields">
                  <label>${labels.username.h()} <input id="srcUser" name="user" value="${analysis.username.h()}" autocomplete="username"></label>
                  <label>${labels.password.h()} <input id="srcPass" name="pass" type="password" value="${analysis.password.h()}" autocomplete="current-password"></label>
                </div>
                <label id="srcMacField">${labels.mac.h()} <input id="srcMac" name="mac" value="${analysis.mac.h()}"></label>
                <button class="go" type="submit">${labels.sendToTv.h()}</button>
                <p id="srcStatus" class="hint"></p>
              </form>
            </div>
            <script>
              var srcForm=document.getElementById('srcForm'), srcType=document.getElementById('srcType'),
                  srcUrl=document.getElementById('srcUrl'), srcUrlLabel=document.getElementById('srcUrlLabel'),
                  srcMacField=document.getElementById('srcMacField'), srcXtreamFields=document.getElementById('srcXtreamFields'),
                  srcStatus=document.getElementById('srcStatus');
              if(srcForm){
                // The type drives the endpoint, the name of the URL field and the fields on show.
                var srcApply=function(){
                  var t=srcType.value;
                  srcForm.action='/'+t+'?pin=$pin';
                  srcUrl.name=(t==='stalker')?'portalUrl':'server';
                  srcUrlLabel.textContent=(t==='stalker')?${labels.portalUrl.js()}:${labels.serverUrl.js()};
                  srcXtreamFields.hidden=(t!=='xtream');
                  srcMacField.hidden=(t!=='stalker');
                };
                srcType.addEventListener('change',srcApply);
                srcApply();
                // An incomplete source is refused by the TV, so catch it here: the user would
                // otherwise lose the whole form to a one-line error page.
                srcForm.addEventListener('submit',function(ev){
                  var t=srcType.value, ok=!!(srcUrl.value||'').trim();
                  if(t==='xtream'){ok=ok&&!!(document.getElementById('srcUser').value||'').trim()&&!!(document.getElementById('srcPass').value||'').trim();}
                  else if(t==='stalker'){ok=ok&&!!(document.getElementById('srcMac').value||'').trim();}
                  if(!ok){ev.preventDefault();srcStatus.textContent=${labels.missingFields.js()};return false;}
                  return true;
                });
              }
            </script>
        """.trimIndent()
    }

    /**
     * The hint that says why the AI did not read the message — and, for a missing key, where the
     * key belongs.
     */
    private fun aiHint(labels: ImportLabels, state: SourceAnalysisAiState): String = when (state) {
        SourceAnalysisAiState.USED -> labels.readByAi
        SourceAnalysisAiState.NO_KEY -> labels.aiNoKey
        SourceAnalysisAiState.INVALID_KEY -> labels.aiInvalidKey
        SourceAnalysisAiState.NO_CREDIT -> labels.aiNoCredit
        SourceAnalysisAiState.FAILED -> labels.aiFailed
        SourceAnalysisAiState.NOT_ASKED -> labels.readByRules
        SourceAnalysisAiState.DISABLED -> labels.aiDisabled
    }

    /**
     * The choice between the addresses the message held. Only shown when there is more than one —
     * the picked one is posted back to the analysis endpoint, which re-reads the message for it.
     */
    private fun urlChoiceHtml(
        labels: ImportLabels,
        analysis: CompanionSourceAnalysis,
        message: String,
        pin: String,
    ): String {
        if (analysis.urls.size < 2) return ""
        val options = analysis.urls.joinToString("\n") { url ->
            """<label class="check"><input type="radio" name="url" value="${url.h()}"${if (url == analysis.url) " checked" else ""}><span class="url">${url.h()}</span></label>"""
        }
        return """
              <form method="post" action="/source/analyze?pin=$pin">
                <input type="hidden" name="message" value="${message.h()}">
                <input type="hidden" name="consent" value="1">
                <p class="hint">${labels.chooseUrl.h()}</p>
                <div class="picks">
                  $options
                </div>
                <button class="go" type="submit">${labels.showUrl.h()}</button>
              </form>
        """.trimIndent()
    }

    fun savedPage(context: Context, payload: CompanionPayload, pin: String): String {
        val c = Copy(context)
        val name = payload.name.ifBlank {
            when (payload.type) {
                SourceType.STALKER -> c.defaultPortal
                SourceType.M3U -> c.defaultPlaylist
                else -> c.defaultIptv
            }
        }
        val body = context.getString(R.string.companion_saved_source_body, name)
        return page(context, c.savedTitle, """
            <div class="card">
              <h1>${c.savedHeading.h()}</h1>
              <p>${body.h()}</p>
              <p><a href="/?pin=$pin">${c.savedSendAnother.h()}</a></p>
            </div>
        """.trimIndent())
    }

    fun backupUploadPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.backupTitle, uploadPage(c, pin, backup = true))
    }

    fun imageUploadPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.imageTitle, uploadPage(c, pin, backup = false))
    }

    private fun uploadPage(c: Copy, pin: String, backup: Boolean): String {
        val heading = if (backup) c.backupHeading else c.imageHeading
        val description = if (backup) c.backupDescription else c.imageDescription
        val fileLabel = if (backup) c.backupFile else c.imageFile
        val choose = if (backup) c.chooseBackup else c.chooseImage
        val endpoint = if (backup) "/backup" else "/background"
        val contentType = if (backup) "application/json" else "text/plain"
        val accept = if (backup) ".own,.json,application/json,application/octet-stream" else "image/*"
        return """
            <div class="card">
              <h1>${heading.h()}</h1>
              <p>${description.h()}</p>
              <form id="f" onsubmit="return false">
                <label>${fileLabel.h()} <input id="file" type="file" accept="$accept" required></label>
                <button class="go" id="send" type="submit">${c.sendToTv.h()}</button>
              </form>
              <p id="status" class="hint"></p>
            </div>
            <script>
              var f=document.getElementById('file'), b=document.getElementById('send'), s=document.getElementById('status');
              document.getElementById('f').addEventListener('submit',function(){
                var file=f.files&&f.files[0];
                if(!file){s.textContent=${choose.js()};return false;}
                ${if (!backup) "if(file.size>25*1024*1024){s.textContent=${c.imageTooLarge.js()};return false;}" else ""}
                b.disabled=true; s.textContent=${c.sending.js()};
                var r=new FileReader();
                r.onload=function(){
                  fetch('$endpoint?pin=$pin',{method:'POST',headers:{'Content-Type':'$contentType'},body:r.result})
                    .then(function(res){
                      if(res.ok){document.open();res.text().then(function(t){document.write(t);document.close();});}
                      else{b.disabled=false;s.textContent=${c.uploadFailed.js()}.replace('__STATUS__',String(res.status));}
                    })
                    .catch(function(){b.disabled=false;s.textContent=${c.couldNotReach.js()};});
                };
                r.onerror=function(){b.disabled=false;s.textContent=${c.couldNotRead.js()};};
                r.readAsDataURL(file); return false;
              });
            </script>
        """.trimIndent()
    }

    /**
     * One-field page: paste a TMDB API key and send it to the TV.
     *
     * The whole point is that a 32-character key is miserable to type on a remote, which is why
     * almost nobody switches to their own key. TMDB's own signup is not mobile-optimised either, so
     * the page links straight to the API settings page rather than making the user find it.
     */
    fun tmdbKeyPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.tmdbTitle, """
            <div class="card">
              <h1>${c.tmdbHeading.h()}</h1>
              <p>${c.tmdbDescription.h()}</p>
              <p><a href="https://www.themoviedb.org/settings/api" target="_blank" rel="noopener">${c.tmdbGetKey.h()}</a></p>
              <form id="f" onsubmit="return false">
                <label>${c.tmdbKeyLabel.h()} <input id="key" type="text" autocomplete="off"
                  autocapitalize="off" spellcheck="false" required></label>
                <button class="go" id="send" type="submit">${c.sendToTv.h()}</button>
              </form>
              <p id="status" class="hint"></p>
            </div>
            <script>
              var k=document.getElementById('key'), b=document.getElementById('send'), s=document.getElementById('status');
              document.getElementById('f').addEventListener('submit',function(){
                var v=(k.value||'').trim();
                // Mirror of the server-side check, purely so a typo is caught before a round trip.
                if(!/^[A-Za-z0-9._-]{16,128}$/.test(v)){s.textContent=${c.tmdbInvalid.js()};return false;}
                b.disabled=true; s.textContent=${c.sending.js()};
                fetch('/tmdbkey?pin=$pin',{method:'POST',headers:{'Content-Type':'text/plain'},body:v})
                  .then(function(res){
                    if(res.ok){document.open();res.text().then(function(t){document.write(t);document.close();});}
                    else{b.disabled=false;s.textContent=${c.uploadFailed.js()}.replace('__STATUS__',String(res.status));}
                  })
                  .catch(function(){b.disabled=false;s.textContent=${c.couldNotReach.js()};});
                return false;
              });
            </script>
        """.trimIndent())
    }

    fun tmdbKeySentPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.savedTitle, """
            <div class="card"><h1>${c.savedHeading.h()}</h1>
              <p>${c.tmdbSentBody.h()}</p><p><a href="/?pin=$pin">${c.tmdbSentLink.h()}</a></p>
            </div>
        """.trimIndent())
    }

    /**
     * One-field page for an AI provider's API key (the Sports hub's DeepSeek key): paste it and send
     * it to the TV.
     *
     * The reason is the same one that produced [tmdbKeyPage]: a long key is painful to type on a
     * remote. The link goes straight to DeepSeek's key page because the Sports hub is the only
     * caller today.
     */
    fun aiKeyPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.aiKeyTitle, """
            <div class="card">
              <h1>${c.aiKeyHeading.h()}</h1>
              <p>${c.aiKeyDescription.h()}</p>
              <p><a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noopener">${c.aiKeyGetKey.h()}</a></p>
              <form id="f" onsubmit="return false">
                <label>${c.aiKeyLabel.h()} <input id="key" type="text" autocomplete="off"
                  autocapitalize="off" spellcheck="false" required></label>
                <button class="go" id="send" type="submit">${c.sendToTv.h()}</button>
              </form>
              <p id="status" class="hint"></p>
            </div>
            <script>
              var k=document.getElementById('key'), b=document.getElementById('send'), s=document.getElementById('status');
              document.getElementById('f').addEventListener('submit',function(){
                var v=(k.value||'').trim();
                // Mirror of the server-side shape check, purely so a typo is caught before a round trip.
                if(!/^[A-Za-z0-9._:-]{8,256}$/.test(v)){s.textContent=${c.aiKeyInvalid.js()};return false;}
                b.disabled=true; s.textContent=${c.sending.js()};
                fetch('/apikey?pin=$pin',{method:'POST',headers:{'Content-Type':'text/plain'},body:v})
                  .then(function(res){
                    if(res.ok){document.open();res.text().then(function(t){document.write(t);document.close();});}
                    else{b.disabled=false;s.textContent=${c.uploadFailed.js()}.replace('__STATUS__',String(res.status));}
                  })
                  .catch(function(){b.disabled=false;s.textContent=${c.couldNotReach.js()};});
                return false;
              });
            </script>
        """.trimIndent())
    }

    fun aiKeySentPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.savedTitle, """
            <div class="card"><h1>${c.savedHeading.h()}</h1>
              <p>${c.aiKeySentBody.h()}</p><p><a href="/?pin=$pin">${c.aiKeySentLink.h()}</a></p>
            </div>
        """.trimIndent())
    }

    fun serviceConfigPage(context: Context, pin: String, openSubtitles: Boolean): String {
        val title = context.getString(if (openSubtitles) R.string.settings_open_subtitles_setup_title else R.string.settings_metadata_remote_advanced)
        val description = context.getString(if (openSubtitles) R.string.companion_open_subtitles_description else R.string.settings_metadata_remote_advanced_description)
        val keyLabel = context.getString(if (openSubtitles) R.string.settings_open_subtitles_api_key else R.string.settings_tmdb_api_key)
        val urlLabel = context.getString(R.string.settings_worker_server_url)
        // OpenSubtitles is an account, not just a key: the credentials are the whole point of doing
        // this from a browser instead of a remote. TMDB has no account, so it keeps the two fields.
        val credentialFields = if (!openSubtitles) "" else """
                <label>${context.getString(R.string.player_subtitles_username).h()} <input id="user" type="text" autocomplete="username" autocapitalize="off" spellcheck="false"></label>
                <label>${context.getString(R.string.player_subtitles_password).h()} <input id="pass" type="password" autocomplete="current-password"></label>
        """.trimIndent()
        // Read back into the POST body only when the fields exist; '' keeps the TMDB body unchanged.
        val credentialBody = if (!openSubtitles) "" else
            ",username:(document.getElementById('user').value||''),password:(document.getElementById('pass').value||'')"
        val send = context.getString(R.string.companion_send_to_tv)
        val sending = context.getString(R.string.companion_sending)
        val failed = context.getString(R.string.companion_upload_failed).replace("%1\$d", "__STATUS__")
        val unreachable = context.getString(R.string.companion_could_not_reach)
        return page(context, title, """
            <div class="card">
              <h1>${title.h()}</h1><p>${description.h()}</p>
              <form id="f" onsubmit="return false">
                $credentialFields
                <label>${keyLabel.h()} <input id="key" type="text" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
                <label>${urlLabel.h()} <input id="url" type="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://"></label>
                <button class="go" id="send" type="submit">${send.h()}</button>
              </form><p id="status" class="hint"></p>
            </div>
            <script>
              var k=document.getElementById('key'),u=document.getElementById('url'),b=document.getElementById('send'),s=document.getElementById('status');
              document.getElementById('f').addEventListener('submit',function(){
                var body=new URLSearchParams({apiKey:(k.value||'').trim(),serverUrl:(u.value||'').trim()$credentialBody}).toString();
                b.disabled=true;s.textContent=${sending.js()};
                fetch('/serviceconfig?pin=$pin',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body})
                  .then(function(res){if(res.ok){return res.text().then(function(t){document.open();document.write(t);document.close();});}b.disabled=false;s.textContent=${failed.js()}.replace('__STATUS__',String(res.status));})
                  .catch(function(){b.disabled=false;s.textContent=${unreachable.js()};});return false;
              });
            </script>
        """.trimIndent())
    }

    fun serviceConfigSentPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.savedTitle, """
            <div class="card"><h1>${c.savedHeading.h()}</h1>
              <p>${context.getString(R.string.companion_service_config_sent).h()}</p>
              <p><a href="/?pin=$pin">${context.getString(R.string.companion_service_config_again).h()}</a></p>
            </div>
        """.trimIndent())
    }

    fun imageSentPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.savedTitle, """
            <div class="card"><h1>${c.savedHeading.h()}</h1>
              <p>${c.savedImageBody.h()}</p><p><a href="/?pin=$pin">${c.savedImageLink.h()}</a></p>
            </div>
        """.trimIndent())
    }

    /**
     * The only page local sync serves. There is nothing for a browser to do here — the other OwnTV
     * app is the client — but the address is discoverable and shown on screen, so someone will type
     * it in, and a blank page or a 404 would look like the feature is broken.
     */
    fun localSyncPage(context: Context): String = page(
        context,
        context.getString(R.string.local_sync_browser_title),
        """
            <div class="card"><h1>${context.getString(R.string.local_sync_browser_title).h()}</h1>
              <p>${context.getString(R.string.local_sync_browser_body).h()}</p>
            </div>
        """.trimIndent(),
    )

    fun backupSentPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.savedTitle, """
            <div class="card"><h1>${c.savedHeading.h()}</h1>
              <p>${c.savedBackupBody.h()}</p><p><a href="/?pin=$pin">${c.savedBackupLink.h()}</a></p>
            </div>
        """.trimIndent())
    }

    fun backupDownloadPage(context: Context, pin: String): String {
        val c = Copy(context)
        return page(context, c.downloadTitle, """
            <div class="card"><h1>${c.downloadHeading.h()}</h1>
              <p>${c.downloadDescription.h()}</p>
              <a class="go" href="/backup.own?pin=$pin" download="owntv-backup.own" style="display:block;text-align:center;text-decoration:none">${c.downloadBackup.h()}</a>
            </div>
        """.trimIndent())
    }

    /**
     * A generic pick list ([CompanionMode.SELECT_ITEMS]): the remote browser ticks rows and posts
     * the chosen ids as repeated `item` fields. [CompanionSelectHtml] builds the three-level body —
     * rows with children drill down, the rest stays on the "manage all" level — and every label
     * comes from resources or the host; nothing here is sport-specific.
     */
    fun selectItemsPage(context: Context, pin: String, title: String, items: List<CompanionSelectItem>): String {
        val c = Copy(context)
        return page(
            context,
            title,
            CompanionSelectHtml.body(
                pin = pin,
                title = title,
                items = items,
                labels = CompanionSelectHtml.Labels(
                    description = c.selectDescription,
                    search = c.selectSearch,
                    save = c.selectSave,
                    back = c.selectBack,
                    manageAll = c.selectManageAll,
                    all = c.selectAll,
                    none = c.selectNone,
                    empty = c.selectEmpty,
                ),
            ),
        )
    }

    fun selectItemsSentPage(context: Context, pin: String, title: String): String {
        val c = Copy(context)
        return page(context, title, """
            <div class="card">
              <h1>${c.selectSentHeading.h()}</h1>
              <p>${c.selectSentBody.h()}</p>
              <p><a href="/?pin=$pin">${c.selectSentLink.h()}</a></p>
            </div>
        """.trimIndent())
    }

    private fun autoRefreshSelect(c: Copy): String = """
        <label>${c.autoRefresh.h()} <select name="autoRefresh">
          <option value="OFF" selected>${c.off.h()}</option>
          <option value="STARTUP">${c.refreshStartup.h()}</option>
          <option value="HOURS_6">${c.refresh6.h()}</option>
          <option value="HOURS_12">${c.refresh12.h()}</option>
          ${c.refreshDays.entries.joinToString("\n          ") { (days, label) ->
        """<option value="MANUAL:$days">${label.h()}</option>"""
    }}
        </select></label>
    """.trimIndent()

    private fun scopeSelect(c: Copy, name: String, label: String, selected: String = "now"): String {
        fun option(value: String, text: String) =
            """<option value="$value"${if (value == selected) " selected" else ""}>${text.h()}</option>"""
        return """
            <label>${label.h()} <select name="$name">
              ${option("now", c.now)}${option("later", c.later)}${option("off", c.off)}
            </select></label>
        """.trimIndent()
    }

    private fun s(@StringRes id: Int, context: Context): String = context.getString(id)

    private fun String.js(): String = JSONObject.quote(this)

    private fun String.h(): String =
        replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
}
